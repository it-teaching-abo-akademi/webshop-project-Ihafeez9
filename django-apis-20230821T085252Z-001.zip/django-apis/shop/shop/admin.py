#account/admin.py

from django.contrib import admin
from .models import UserData

admin.site.register(UserData)